<?php
class msProductDataManagerController extends ResourceDataManagerController {}